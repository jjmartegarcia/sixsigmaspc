# Welcome
Six Sigma SPC is a library for Statistical Process Control.

## Installation
pip install sixsigmaspc

See the test scripts for examples how to use.

